# CapsuleSoccerApp
Deploying the game on Heroku => https://capsulesoccer.herokuapp.com/
